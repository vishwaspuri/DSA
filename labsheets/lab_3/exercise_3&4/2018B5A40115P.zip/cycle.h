#include "linked_list.h"

extern bool testCyclic(ListNode *head); // Checks whether linkedlist has cycle or not